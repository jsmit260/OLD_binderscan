import os
import timeit
import datetime

r = '192.168.3.0/24'
for i in range(1,101):
    start = timeit.default_timer()
    # Adjusted
    os.system("sudo nmap --disable-arp-ping -sS {} -oN nmap_runs/icmp_disabled/nmap_icmp_disabled_run_{}".format(r,i))
    stop = timeit.default_timer()
    total_time = stop - start
    net_class = "C"
    # output running time in a nice format.
    mins, secs = divmod(total_time, 60)
    hours, mins = divmod(mins, 60)
    time_csv = "%d:%d:%d.\n" %(hours, mins, secs)
    dt = datetime.datetime.now().strftime('%Y-%m-%d-%H%M')
    time_log = "{},{},{},{}".format(dt,r,net_class,time_csv)
    with open("nmap_runs/icmp_disabled/nmap_only_tcp_class_C_ICMP_Disabled_Time.csv","a+") as f:
        print("[*]Writing To Time Log[*]")
        f.write(time_log)
        print("[*]Time Log Updated[*]")
